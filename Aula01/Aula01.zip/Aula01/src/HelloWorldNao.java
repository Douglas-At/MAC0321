public class HelloWorldNao {
   public static void main (String[] args) {

       float x = (float)1/47;
       x = x * 47;
       
       double y = (double)1/47;
       y  = y * 47;
       
      System.out.println("Qualquer coisa menos Hello World! " + x + " " + y );
   }
}
