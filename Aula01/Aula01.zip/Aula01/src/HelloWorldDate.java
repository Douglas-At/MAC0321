import java.util.Date;

public class HelloWorldDate {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
	    System.out.println(new Date());
    }
}
